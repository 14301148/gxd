package WebServer;
import java.io.File;

public class Constants {
 public static final String WEB_ROOT = System.getProperty("user.dir")
 + File.separator + "WebRoot";
 public static final String WEB_SERVLET_ROOT = System.getProperty("user.dir")
 + File.separator + "webroot" + File.separator +"web-inf"+File.separator+"classes"+File.separator+"Servlet"+File.separator;
  
}
